from abc import ABCMeta, abstractmethod
class Calculator(metaclass=ABCMeta):
    @abstractmethod
    def calculate(self, num1, num2):
        pass
class RCalculator(Calculator):
    def calculate(self, num1, num2, op):
        num1=int(num1)
        num2=int(num2)
        if op == '+':
            return num1 + num2
        elif op == '-':
            return num1 - num2
        elif op == '*':
            return num1 * num2
        else:
            return num1 / num2

class Calculator(Calculator):
    def __init__(self):
        self.r_calculator = RCalculator()

    def calculate(self, num1, num2, operator):
        return self.r_calculator.calculate(num1, num2, operator)
proxy = Calculator()
x,y,z=input('계산기 : ').split()
result = proxy.calculate(x, z, y)
print(result)  
class Client:
    def __init__(self):
        self.calculator=Calculator()
        